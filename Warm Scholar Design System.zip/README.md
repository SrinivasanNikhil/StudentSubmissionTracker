# Warm Scholar — Design System

A warm-editorial design system for the personal brand of **Nikhil Srinivasan**, Senior Lecturer in Data, Analytics & AI at the UGA Terry College of Business. It powers slides, websites, and applications across three audiences at once: students, corporate sponsors, and faculty peers.

This is an **independent identity** — deliberately *not* UGA-branded. Where the live site currently leans on UGA red, Inter, and bento-grid gradients, Warm Scholar replaces that with warm neutrals, two earth accents (terracotta + olive), Fraunces headlines, and IBM Plex for everything else. The system favors generous whitespace, one accent action per view, and hairline borders over drop shadows.

> **Two non-negotiables:** terracotta (`--accent`) never carries text on a light background (contrast), and Fraunces is for headlines only.

---

## Sources

This system was built from the spec provided by the user, cross-referenced against Nikhil's existing website for real content and product context.

- **GitHub repo (live personal site):** https://github.com/SrinivasanNikhil/SrinivasanNikhil.github.io
  - `index.html` — home / about / bento grid / resources
  - `teaching.html` — courses, awards, grants, institutions
  - `research.html` — research focus and publications
  - `css/custom.css` — current (UGA-branded) styles
  - *Note: the live site uses Inter + UGA red. Warm Scholar is a redesign of this content, not a copy of its current visuals. Explore the repo to pull additional copy or course data.*
- **Products referenced:** SQL Comparator (`comparator.nsrinivasan.com`), the free *Intro to SQL* online textbook, and the YouTube channel `@nikhilsrinivasan`.

The reader is encouraged to browse the repository above to do a better job building designs based on this product.

---

## Who this is for / product context

**Nikhil Srinivasan** — PhD in Information Systems (Case Western, 2013). 12+ years at UGA, 10+ courses, 5 teaching awards, 3 teaching-innovation grants. Teaches data management, analytics, and programming (SQL, Python, R, AWS). Research in social network analysis, big data analytics, and information systems design.

The surfaces this system dresses:
1. **Personal / academic website** — home, teaching, research. The primary marketing surface for students and sponsors.
2. **Teaching & learning apps** — SQL Comparator, the *Intro to SQL* textbook reader, course tooling. App-state semantics (success/warning/danger/info), code blocks, and tables live here.
3. **Slides** — lecture decks and sponsor presentations. Warm white surface, restrained type, demo-forward.

---

## Index / manifest

Root files:
- `README.md` — this file (context, content + visual foundations, iconography, manifest).
- `SKILL.md` — Agent-Skill front-matter so this folder can be used directly inside Claude Code.
- `colors_and_type.css` — **source of truth.** All color, type, spacing, radius, and elevation tokens as CSS variables, plus semantic element defaults. Both light and `[data-theme="dark"]` values.
- `CLAUDE.md` — n/a unless persistent instructions are added.

Folders:
- `preview/` — small HTML cards rendered in the Design System tab (colors, type, spacing, components, brand). `preview.css` is shared.
- `assets/` — brand assets + notes (`assets/README.md`). The wordmark is typographic (Fraunces); no raster logo exists upstream.
- `ui_kits/website/` — hi-fi recreation of the academic website in the Warm Scholar system (`index.html` + JSX components + `README.md`).
- `ui_kits/app/` — hi-fi recreation of the SQL learning app / textbook reader (`index.html` + JSX components + `README.md`).
- `slides/` — sample lecture deck: `index.html` (full 6-slide deck via `deck-stage.js`) plus one standalone HTML per slide type (`title`, `section`, `content`, `code-demo`, `quote`, `closing`) and shared `slides.css`.

---

## 1. Content fundamentals (voice & UI copy)

The voice is **direct, concrete, and unhyped** — a senior lecturer who respects the reader's time.

- **Casing:** sentence case *everywhere* — UI, headings, slide labels, buttons. Never title case, never all caps. (e.g. "Browse courses", "Data management & analytics".)
- **Person:** first person for the bio voice ("I design courses that bridge theory and practice"), second person for instructions to students ("Submit your assignment before Friday"). Warm but not chummy.
- **Tone:** plain and specific. No motivational filler, no hype, **no exclamation marks in UI.** Active voice, short sentences.
- **Buttons name the action:** "Browse courses" not "Click here"; "Submit assignment" not "Go".
- **Errors are plain and specific:** "File must be under 10 MB" not "Something went wrong".
- **Emoji:** none in UI. Ever.
- **Real-copy examples (lifted from the source site):**
  - "I help students master data, analytics, and programming to build real-world business solutions."
  - "Every concept taught with real datasets and practical exercises. No death by PowerPoint."
  - "Curriculum aligned with what employers actually need."
- **Vibe:** editorial and scholarly, but applied. Concrete nouns (SQL, normalization, pipelines, datasets) over abstractions. Numbers when they're earned (awards, years, enrollment) — never decorative stat-slop.

---

## 2. Visual foundations

**Color.** Three layers: warm neutrals as the base (`--paper` cream page, `--surface` warm white for cards/slides), two earth accents (terracotta `--accent` decorative-only; sienna `--accent-deep` the action workhorse; olive `--secondary` for tags/success), and semantic states that may break warmth for clarity. Imagery and palette skew **warm** — clay, sienna, olive, cream — never cool blues or purple gradients. One accent action per view; don't stack competing terracotta/sienna elements.

**Type.** Fraunces (opsz on) for headlines and the wordmark *only*; IBM Plex Sans for body, UI, labels, buttons, nav; IBM Plex Mono for code, SQL/R, and tabular figures. **Weights 400 and 500 only — never 600/700.** Headlines carry a slight negative tracking (-0.01em); eyebrows carry +0.06em. Conservative fallback: swap Fraunces 1:1 for Newsreader if it reads too characterful for a sponsor deck.

**Spacing & layout.** 4px base scale (4·8·12·16·24·32·48·64). 12-column web grid; reading width ~720px; page max ~1100–1200px. Text is **left-aligned** — never center paragraphs or long headlines. Section rhythm comes from whitespace, not boxes-inside-boxes. When unsure, add space before adding a border.

**Backgrounds.** Flat warm fills only. `--paper` for pages, `--surface` for cards and slides, `--surface-raised` for code. **No gradients, no photographic hero washes, no repeating textures.** If photos are used: warm-toned, natural light, real subjects — never corporate gradient stock.

**Borders, radius, elevation.** 1px `--line` hairlines are the default separator; `--border-strong` for emphasis. Radii: 6px badges, 8px controls/inputs, 12px cards, 16px panels — but single-sided accent borders (`border-left`) stay square (radius 0). **Elevation is borders and background steps, not shadows.** Exactly one soft shadow exists, reserved for menus and modals: `0 4px 16px rgba(41,32,26,0.08)`.

**Cards.** `--surface` background, 1px `--line` border, 12px radius, 16–20px padding, **no shadow by default.** A left-accent variant uses a 3px terracotta `border-left` and squared corners.

**Animation.** Restrained. Short, eased transitions (≈150–200ms, ease-in-out) on color/opacity. No bounces, no infinite decorative loops, no parallax. Respect `prefers-reduced-motion`.

**Hover / press states.** Primary buttons darken ~10% on hover; ghost buttons fill with `--accent-tint`; links underline on hover (and always underline inside long body text). Press states settle into the darker color rather than scaling. Avoid scale-up "pop" interactions (a trope of the old site being replaced).

**Focus.** Visible focus on every interactive element — a 2px sienna ring at ~40% alpha (`box-shadow: 0 0 0 3px rgba(138,63,34,.25)`).

**Transparency & blur.** Used sparingly. A subtle backdrop on a sticky nav is acceptable; otherwise prefer solid warm fills. No glassmorphism panels.

**Charts.** Categorical order sienna → olive → terracotta → info → warning → neutrals. Hairline gridlines, transparent plot background, labels in `--body`/`--muted`. Color encodes category, not order — no rainbow sequences.

---

## 3. Iconography

- **System:** [Lucide](https://lucide.dev) outline icons (Tabler is an acceptable alternative — same outline character). Loaded from CDN (`https://unpkg.com/lucide@latest/dist/umd/lucide.min.js`); there is no bespoke icon font or sprite in the source repo.
- **Style:** outline only, ~1.5–2px stroke (we use 1.75), `currentColor` so icons inherit text color, 16–20px inline. **No filled glyphs**, no duotone, no mixed icon families.
- **Color:** icons default to text color; a key icon may take `--accent-deep`. Avoid coloring decorative icons terracotta on light backgrounds.
- **Emoji:** never used as iconography in UI.
- **Unicode:** a small set of typographic characters is acceptable inline (· middot separators, → arrows where a real icon is overkill, ⚠ only paired with text in error messages) — but prefer a real Lucide glyph for anything interactive.
- **Brand mark:** typographic, not pictorial — an "NS" monogram set in Fraunces 500, or the full name as a wordmark. See `preview/brand-wordmark.html`. The source site has only a `favicon.ico` and a text "NS" mark; no logo art was available to import, so none is included here.

---

## 4. Accessibility

Target WCAG AA. Body and interactive text use `--ink`, `--body`, or `--accent-deep` (all clear AA on cream/surface). `--accent` (terracotta) clears AA only for large text — treat it as decorative, never small body text, never behind white. `--muted` is for non-essential metadata at 14px+. Never signal state by color alone — pair with an icon, label, or message. Visible focus on every interactive element.

---

*See `SKILL.md` to use this folder as a downloadable Claude Code skill.*
