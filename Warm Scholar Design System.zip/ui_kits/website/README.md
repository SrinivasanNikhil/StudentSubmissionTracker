# Website UI kit — Warm Scholar

A hi-fi recreation of Nikhil Srinivasan's academic website, redrawn in the Warm Scholar system (warm neutrals, Fraunces headlines, sienna actions). This is a redesign of the content currently at `SrinivasanNikhil.github.io` — same material, new identity (the live site uses Inter + UGA red, which this deliberately replaces).

## Run it
Open `index.html`. It's a click-through: switch between **Home / Teaching / Research** in the nav, and **Get in touch** opens a contact modal.

## Files
- `index.html` — app shell + view router + contact modal.
- `kit.css` — kit styles, importing the root `colors_and_type.css`.
- `components.jsx` — `Icon`, `Button`, `Tag`, `Nav`, `SectionHead`, `CourseCard`, `ResourceCard`, `AwardItem`, `StatBand`, `Footer`.
- `views.jsx` — `HomeView`, `TeachingView`, `ResearchView` (real course/award/grant data).

## Coverage
Sticky blurred nav, editorial hero, dark stat band, feature + resource cards, course grid with tags, awards (left-accent) + grants, education cards, contact modal with focus-ring inputs, footer. Icons are Lucide outline via CDN.

## Notes
Components are cosmetic recreations, not production code. All copy is sentence case; one sienna primary action per view; cards are hairline + radius-12 with no shadow.
