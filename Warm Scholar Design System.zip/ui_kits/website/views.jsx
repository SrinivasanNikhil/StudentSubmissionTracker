/* Warm Scholar website kit — page views. */

const UNDERGRAD = [
  { code: "MIST 4610", title: "Data management & analytics", desc: "SQL, database design, normalization, and cloud-based data solutions.", tag: "Popular", tagTone: "clay" },
  { code: "BUSN 3020E", title: "SQL for business analytics", desc: "Practical SQL applications in real business environments.", tag: "Online", tagTone: "olive" },
  { code: "MIST 2090", title: "Introduction to information systems", desc: "Business models, data management, and technology fundamentals.", tag: "Core", tagTone: "olive" },
  { code: "MIST 4600", title: "Computer programming in business", desc: "Programming fundamentals with Python and Java.", tag: null },
];
const GRAD = [
  { code: "MIST 7510E", title: "Database management", desc: "Advanced SQL, data warehousing, and database security.", tag: "Online", tagTone: "olive" },
  { code: "MIST 7600", title: "Data analytics", desc: "Business analytics using SQL, R, and Tableau.", tag: null },
  { code: "MIST 7571E", title: "Internet programming II", desc: "Web development with modern frameworks, React, and APIs.", tag: "Online", tagTone: "olive" },
  { code: "MIST 7590E", title: "Technology capstone project", desc: "Applied technology solutions for real business challenges.", tag: "Capstone", tagTone: "clay" },
];

function HomeView({ onNav }) {
  return (
    <div>
      <section className="ws-wrap section" style={{ paddingTop: 88, paddingBottom: 56 }}>
        <div className="reading">
          <div className="eyebrow" style={{ marginBottom: 16 }}>Senior lecturer · UGA Terry College of Business</div>
          <h1 className="h-display">Data, analytics, and AI — taught for the real world.</h1>
          <p className="lead" style={{ marginTop: 22 }}>I help students master data, analytics, and programming to build solutions that hold up outside the classroom — from production SQL to pipelines on AWS.</p>
          <div style={{ display: "flex", gap: 12, marginTop: 28 }}>
            <Button variant="primary" icon="arrow-right" onClick={() => onNav("teaching")}>Browse courses</Button>
            <Button variant="ghost" href="https://www.linkedin.com/in/nikhil-srinivasan">LinkedIn</Button>
          </div>
        </div>
      </section>

      <StatBand stats={[
        { num: "12+", label: "Years at UGA" },
        { num: "10+", label: "Courses taught" },
        { num: "5", label: "Teaching awards" },
        { num: "3", label: "Innovation grants" },
      ]} />

      <section className="ws-wrap section">
        <SectionHead eyebrow="What I do" title="Bridging theory and practice">
          Data management, analytics, and modern software development — taught with real datasets and a demo-forward classroom.
        </SectionHead>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
          <ResourceCard icon="database" title="Data & databases" desc="SQL fundamentals, normalization, warehousing, and cloud data on AWS." href="#" />
          <ResourceCard icon="bar-chart-3" title="Analytics" desc="Business analytics with SQL, R, and Tableau — turning questions into evidence." href="#" />
          <ResourceCard icon="terminal" title="Programming" desc="Python, Java, and web development for students who build, not just describe." href="#" />
        </div>
      </section>

      <hr className="divider" />

      <section className="ws-wrap section">
        <SectionHead eyebrow="Resources" title="Tools I've built for students">Free, practical, and used in my own courses.</SectionHead>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
          <ResourceCard icon="git-compare" title="SQL Comparator" desc="Compare SQL queries side-by-side for teaching and learning." href="https://comparator.nsrinivasan.com" />
          <ResourceCard icon="book-open" title="Intro to SQL" desc="A free online textbook for SQL fundamentals." href="#" />
          <ResourceCard icon="play" title="YouTube" desc="Video tutorials on data and programming." href="https://youtube.com/@nikhilsrinivasan" />
        </div>
      </section>
    </div>
  );
}

function TeachingView() {
  return (
    <div>
      <section className="ws-wrap section" style={{ paddingTop: 72, paddingBottom: 40 }}>
        <div className="reading">
          <div className="eyebrow" style={{ marginBottom: 14 }}>Teaching · 2013 – present</div>
          <h1 className="h1">Courses that bridge theory and practice</h1>
          <p className="lead" style={{ marginTop: 16 }}>Every concept taught with real datasets and practical exercises. No death by PowerPoint.</p>
        </div>
      </section>

      <section className="ws-wrap" style={{ paddingBottom: 32 }}>
        <h3 className="h3" style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 18 }}>
          <span style={{ width: 9, height: 9, borderRadius: "50%", background: "var(--secondary)" }} /> Undergraduate
        </h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 16 }}>
          {UNDERGRAD.map((c) => <CourseCard key={c.code} {...c} />)}
        </div>
      </section>

      <section className="ws-wrap section" style={{ paddingTop: 28 }}>
        <h3 className="h3" style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 18 }}>
          <span style={{ width: 9, height: 9, borderRadius: "50%", background: "var(--accent)" }} /> Graduate
        </h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 16 }}>
          {GRAD.map((c) => <CourseCard key={c.code} {...c} />)}
        </div>
      </section>

      <hr className="divider" />

      <section className="ws-wrap section">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 48 }}>
          <div>
            <SectionHead eyebrow="Recognition" title="Teaching awards" />
            <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              <AwardItem title="Hugh O. Nourse MBA Teaching Award" sub="2024" />
              <AwardItem title="Student Career Success Influencer Award" sub="2022, 2023, 2024, 2025" />
              <AwardItem title="Terry College Outstanding Teacher Award" sub="2018" />
              <AwardItem title="Teaching Academy Fellowship" sub="University of Georgia" />
            </div>
          </div>
          <div>
            <SectionHead eyebrow="Funded work" title="Innovation grants" />
            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              <div className="card"><h3 className="h3" style={{ fontSize: 17 }}>AI-based tools for data analytics teaching</h3><p className="p" style={{ fontSize: 14, marginTop: 6 }}>Developing AI tools for evaluation and feedback.</p><div className="meta" style={{ marginTop: 8, color: "var(--accent-deep)" }}>2025 · Terry College of Business</div></div>
              <div className="card"><h3 className="h3" style={{ fontSize: 17 }}>Interactive data analytics content</h3><p className="p" style={{ fontSize: 14, marginTop: 6 }}>Interactive content for data analytics coursework.</p><div className="meta" style={{ marginTop: 8, color: "var(--accent-deep)" }}>2023 · Terry College of Business</div></div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function ResearchView() {
  const areas = [
    { icon: "share-2", title: "Social network analysis", desc: "How relationships and structure shape information flow in organizations." },
    { icon: "database", title: "Big data analytics", desc: "Methods and infrastructure for analysis at scale." },
    { icon: "layout-grid", title: "Information systems design", desc: "Designing systems that fit the way people and organizations actually work." },
  ];
  return (
    <div>
      <section className="ws-wrap section" style={{ paddingTop: 72, paddingBottom: 40 }}>
        <div className="reading">
          <div className="eyebrow" style={{ marginBottom: 14 }}>Research</div>
          <h1 className="h1">Where my questions live</h1>
          <p className="lead" style={{ marginTop: 16 }}>PhD in Information Systems (Case Western, 2013). My work sits between the social and the technical — how systems and the people who use them shape one another.</p>
        </div>
      </section>
      <section className="ws-wrap" style={{ paddingBottom: 48 }}>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
          {areas.map((a) => (
            <div className="card" key={a.title}>
              <span className="icon-chip"><Icon name={a.icon} size={20} /></span>
              <h3 className="h3" style={{ marginTop: 14 }}>{a.title}</h3>
              <p className="p" style={{ fontSize: 14, marginTop: 6 }}>{a.desc}</p>
            </div>
          ))}
        </div>
      </section>
      <hr className="divider" />
      <section className="ws-wrap section">
        <SectionHead eyebrow="Background" title="Education" />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 }}>
          <div className="card"><div className="meta" style={{ color: "var(--accent-deep)" }}>2013</div><h3 className="h3" style={{ marginTop: 8, fontSize: 17 }}>PhD, Information Systems</h3><p className="p" style={{ fontSize: 14, marginTop: 4 }}>Case Western Reserve University</p></div>
          <div className="card"><div className="meta" style={{ color: "var(--accent-deep)" }}>2001</div><h3 className="h3" style={{ marginTop: 8, fontSize: 17 }}>MS, Telecom & Network Mgmt</h3><p className="p" style={{ fontSize: 14, marginTop: 4 }}>Syracuse University</p></div>
          <div className="card"><div className="meta" style={{ color: "var(--accent-deep)" }}>1999</div><h3 className="h3" style={{ marginTop: 8, fontSize: 17 }}>BE, Electronics & Telecom</h3><p className="p" style={{ fontSize: 14, marginTop: 4 }}>Marathwada University, India</p></div>
        </div>
      </section>
    </div>
  );
}

Object.assign(window, { HomeView, TeachingView, ResearchView });
