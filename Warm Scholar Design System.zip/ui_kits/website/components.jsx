/* Warm Scholar website kit — shared components.
   Cosmetic recreations; Lucide for icons. Exported to window. */

function Icon({ name, size = 18, color, style }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (ref.current && window.lucide) {
      ref.current.innerHTML = "";
      const el = document.createElement("i");
      el.setAttribute("data-lucide", name);
      ref.current.appendChild(el);
      window.lucide.createIcons({ icons: undefined, nameAttr: "data-lucide" });
      const svg = ref.current.querySelector("svg");
      if (svg) { svg.style.width = size + "px"; svg.style.height = size + "px"; svg.style.strokeWidth = "1.75"; }
    }
  }, [name, size]);
  return <span ref={ref} style={{ display: "inline-flex", color: color || "currentColor", ...style }} />;
}

function Button({ variant = "primary", children, icon, onClick, href }) {
  const cls = "btn " + (variant === "primary" ? "btn-primary" : "btn-ghost");
  const inner = <>{children}{icon ? <Icon name={icon} size={16} /> : null}</>;
  if (href) return <a className={cls} href={href} target="_blank" rel="noreferrer">{inner}</a>;
  return <button className={cls} onClick={onClick}>{inner}</button>;
}

function Tag({ tone = "olive", children }) {
  return <span className={"tag " + (tone === "clay" ? "tag-clay" : "tag-olive")}>{children}</span>;
}

function Nav({ active, onNav }) {
  const links = [["home", "Home"], ["teaching", "Teaching"], ["research", "Research"]];
  return (
    <nav className="ws-nav">
      <div className="ws-wrap ws-nav-inner">
        <div className="ws-mark" onClick={() => onNav("home")}>Nikhil Srinivasan</div>
        <div className="ws-navlinks">
          {links.map(([id, label]) => (
            <button key={id} className={"ws-navlink" + (active === id ? " active" : "")} onClick={() => onNav(id)}>{label}</button>
          ))}
          <Button variant="primary" onClick={() => onNav("contact")}>Get in touch</Button>
        </div>
      </div>
    </nav>
  );
}

function SectionHead({ eyebrow, title, children, align = "left" }) {
  return (
    <div style={{ textAlign: align, maxWidth: align === "center" ? 640 : "none", margin: align === "center" ? "0 auto" : 0, marginBottom: 36 }}>
      {eyebrow ? <div className="eyebrow" style={{ marginBottom: 10 }}>{eyebrow}</div> : null}
      <h2 className="h1">{title}</h2>
      {children ? <p className="lead" style={{ marginTop: 14 }}>{children}</p> : null}
    </div>
  );
}

function CourseCard({ code, title, desc, tag, tagTone }) {
  return (
    <div className="card">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
        <span className="mono" style={{ fontSize: 12, color: "var(--muted)" }}>{code}</span>
        {tag ? <Tag tone={tagTone}>{tag}</Tag> : null}
      </div>
      <h3 className="h3" style={{ marginTop: 12 }}>{title}</h3>
      <p className="p" style={{ marginTop: 6, fontSize: 14 }}>{desc}</p>
    </div>
  );
}

function ResourceCard({ icon, title, desc, href }) {
  return (
    <a className="card card-link" href={href} target="_blank" rel="noreferrer">
      <span className="icon-chip"><Icon name={icon} size={20} /></span>
      <h3 className="h3" style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 8 }}>{title}</h3>
      <p className="p" style={{ marginTop: 6, fontSize: 14 }}>{desc}</p>
    </a>
  );
}

function AwardItem({ title, sub }) {
  return (
    <div style={{ borderLeft: "3px solid var(--accent)", padding: "10px 0 10px 16px" }}>
      <div className="label" style={{ fontWeight: 500, color: "var(--ink)", fontSize: 15 }}>{title}</div>
      <div className="meta" style={{ marginTop: 3 }}>{sub}</div>
    </div>
  );
}

function StatBand({ stats }) {
  return (
    <div className="statband">
      <div className="ws-wrap statgrid">
        {stats.map((s) => (
          <div key={s.label}>
            <div className="statnum">{s.num}</div>
            <div className="statlabel">{s.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Footer() {
  return (
    <div className="ws-wrap">
      <div className="footer">
        <span>© 2025 Nikhil Srinivasan · University of Georgia · Terry College of Business</span>
        <span style={{ display: "flex", gap: 16 }}>
          <a href="mailto:nsrini@uga.edu">nsrini@uga.edu</a>
          <a href="https://www.linkedin.com/in/nikhil-srinivasan" target="_blank" rel="noreferrer">LinkedIn</a>
        </span>
      </div>
    </div>
  );
}

Object.assign(window, { Icon, Button, Tag, Nav, SectionHead, CourseCard, ResourceCard, AwardItem, StatBand, Footer });
