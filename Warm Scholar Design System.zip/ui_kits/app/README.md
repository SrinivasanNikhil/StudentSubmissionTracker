# App UI kit — Warm Scholar

A hi-fi recreation of an interactive SQL learning workspace — the surface behind the *Intro to SQL* textbook and the SQL Comparator tool — drawn in the Warm Scholar system. It demonstrates the **application-state** half of the system: semantic feedback colors, code blocks with syntax tints, data tables, and dense navigation chrome.

## Run it
Open `index.html`. Pick a lesson in the left rail; on the lesson page press **Run query** to execute the sample SQL — a result table and a success banner appear. **Reset** returns to the idle (info-banner) state.

## Files
- `index.html` — workspace shell (sidebar + topbar + lesson + console) with run/reset state.
- `appkit.css` — kit styles, importing the root `colors_and_type.css`.
- `components.jsx` — `Icon`, `Button`, `Sidebar`, `TopBar`, `Sql` (mini SQL highlighter), `Console`, `ResultTable`, `Banner`.

## Coverage
Two-pane app layout, branded sidebar with lesson list + completion checks + user footer, breadcrumb topbar with progress bar, editorial lesson body, code console with window chrome and sienna/olive/ochre syntax tints, tabular result grid, and success / info / danger feedback banners (semantic colors paired with icons — never color alone).

## Notes
Cosmetic recreation, not a real SQL engine — Run swaps in a canned result set. Syntax highlighting covers a small keyword set for demo fidelity.
