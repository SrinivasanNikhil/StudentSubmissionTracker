/* Warm Scholar app kit — SQL workspace components. Exported to window. */

function Icon({ name, size = 16, color, style }) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (ref.current && window.lucide) {
      ref.current.innerHTML = "";
      const el = document.createElement("i");
      el.setAttribute("data-lucide", name);
      ref.current.appendChild(el);
      window.lucide.createIcons({ nameAttr: "data-lucide" });
      const svg = ref.current.querySelector("svg");
      if (svg) { svg.style.width = size + "px"; svg.style.height = size + "px"; }
    }
  }, [name, size]);
  return <span ref={ref} style={{ display: "inline-flex", color: color || "currentColor", ...style }} />;
}

function Button({ variant = "primary", children, icon, onClick }) {
  return (
    <button className={"btn " + (variant === "primary" ? "btn-primary" : "btn-ghost")} onClick={onClick}>
      {icon ? <Icon name={icon} size={15} /> : null}{children}
    </button>
  );
}

function Sidebar({ lessons, activeId, onPick }) {
  return (
    <aside className="sidebar">
      <div className="sb-head">
        <div className="sb-mark">NS</div>
        <div>
          <div className="sb-title">Intro to SQL</div>
          <div className="sb-sub">Interactive textbook</div>
        </div>
      </div>
      <div className="sb-scroll">
        <div className="sb-group">MODULE 2 · QUERYING</div>
        {lessons.map((l) => (
          <button key={l.id} className={"sb-item" + (l.id === activeId ? " active" : "")} onClick={() => onPick(l.id)}>
            <Icon name={l.icon} size={16} />
            <span>{l.title}</span>
            {l.done ? <span className="chk"><Icon name="check" size={15} /></span> : null}
          </button>
        ))}
      </div>
      <div className="sb-foot">
        <div className="avatar">AL</div>
        <div style={{ lineHeight: 1.2 }}>
          <div style={{ fontSize: 13, color: "var(--ink)", fontWeight: 500 }}>Ada Lin</div>
          <div style={{ fontSize: 11, color: "var(--muted)" }}>MIST 4610</div>
        </div>
      </div>
    </aside>
  );
}

function TopBar({ crumb, progress }) {
  return (
    <div className="topbar">
      <div className="crumbs"><span>Intro to SQL</span><Icon name="chevron-right" size={14} /><span>Querying</span><Icon name="chevron-right" size={14} /><b>{crumb}</b></div>
      <div className="prog">
        <span className="meta" style={{ fontSize: 12, color: "var(--muted)" }}>{progress}% complete</span>
        <div className="progbar"><span style={{ width: progress + "%" }} /></div>
      </div>
    </div>
  );
}

// Highlight a small SQL string into tinted spans.
function Sql({ children }) {
  const KW = /\b(SELECT|FROM|WHERE|GROUP BY|ORDER BY|JOIN|USING|AS|DESC|ASC|LIMIT|ON|AND|HAVING|COUNT|INNER)\b/g;
  const html = children
    .replace(/--.*$/gm, (m) => `\u0000cm${m}\u0001`)
    .replace(/'[^']*'/g, (m) => `\u0000num${m}\u0001`)
    .replace(/\b\d+\b/g, (m) => `\u0000num${m}\u0001`)
    .replace(KW, (m) => `\u0000kw${m}\u0001`);
  const parts = html.split(/\u0000|\u0001/).filter((p) => p !== "");
  return <div className="editor">{parts.map((p, i) => {
    if (p.startsWith("kw")) return <span key={i} className="kw">{p.slice(2)}</span>;
    if (p.startsWith("cm")) return <span key={i} className="cm">{p.slice(2)}</span>;
    if (p.startsWith("num")) return <span key={i} className="num">{p.slice(3)}</span>;
    return <span key={i}>{p}</span>;
  })}</div>;
}

function Console({ sql, onRun, onReset, running }) {
  return (
    <div className="console">
      <div className="console-bar">
        <span className="dot" style={{ background: "var(--accent)" }} />
        <span className="dot" style={{ background: "var(--secondary)" }} />
        <span className="dot" style={{ background: "var(--border-strong)" }} />
        <span className="console-file">query.sql</span>
        <div className="console-actions">
          <Button variant="ghost" icon="rotate-ccw" onClick={onReset}>Reset</Button>
          <Button variant="primary" icon="play" onClick={onRun}>{running ? "Running…" : "Run query"}</Button>
        </div>
      </div>
      <Sql>{sql}</Sql>
    </div>
  );
}

function ResultTable({ columns, rows }) {
  return (
    <div className="result">
      <div className="result-head"><Icon name="table-2" size={15} color="var(--muted)" /><span style={{ color: "var(--body)" }}>{rows.length} rows · {(rows.length * 0.4 + 1.2).toFixed(1)} ms</span></div>
      <table>
        <thead><tr>{columns.map((c) => <th key={c}>{c}</th>)}</tr></thead>
        <tbody>{rows.map((r, i) => <tr key={i}>{r.map((cell, j) => <td key={j}>{cell}</td>)}</tr>)}</tbody>
      </table>
    </div>
  );
}

function Banner({ tone, icon, children }) {
  return <div className={"banner banner-" + tone}><Icon name={icon} size={18} /><div>{children}</div></div>;
}

Object.assign(window, { Icon, Button, Sidebar, TopBar, Sql, Console, ResultTable, Banner });
