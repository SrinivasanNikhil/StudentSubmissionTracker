# assets/

Brand assets for the Warm Scholar system.

The brand mark is **typographic, not pictorial** — there is no raster/SVG logo. The
upstream site (`SrinivasanNikhil.github.io`) ships only a `favicon.ico` and a text
"NS" mark, so no logo art was available to import.

Reproduce the mark from type instead (see `preview/brand-wordmark.html` for the
canonical treatments):

- **Seal** — "NS" set in Fraunces 500 inside a hairline terracotta ring (the S in
  sienna `--accent-deep`). Use for favicons, avatars, stamps.
- **Monogram** — interlocked "NS", N in `--ink`, S nested in sienna. Avatar / app chrome.
- **Signature lockup** — "Nikhil Srinivasan." in Fraunces 500 with a terracotta period,
  over a tracked `DATA · ANALYTICS · AI` role line. Headers and deck footers.

Icons: Lucide outline set, loaded from CDN (`https://unpkg.com/lucide@latest`). No
bespoke icon font. See the Iconography section of the root `README.md`.
