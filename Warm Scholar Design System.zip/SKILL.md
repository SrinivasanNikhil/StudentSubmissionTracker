---
name: warm-scholar-design
description: Use this skill to generate well-branded interfaces and assets for Nikhil Srinivasan's "Warm Scholar" identity (data/analytics/AI teaching brand), either for production or throwaway prototypes/mocks. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping slides, websites, and apps.
user-invocable: true
---

# Warm Scholar — design skill

A warm-editorial system: warm-neutral base, two earth accents (terracotta + olive), Fraunces headlines, IBM Plex for everything else. Independent identity — **not** UGA-branded.

## Start here
1. Read `README.md` — full context, content fundamentals, visual foundations, iconography, and the file manifest.
2. `colors_and_type.css` is the **source of truth** for color/type/spacing/radius tokens (light + `[data-theme="dark"]`). Import or copy it.
3. Browse `preview/` for live token/component specimens, `ui_kits/website/` and `ui_kits/app/` for component recreations, and `slides/` for the slide system.

## Two non-negotiables
- Terracotta (`--accent`) never carries text on a light background — use sienna (`--accent-deep`) for actions/links.
- Fraunces is for headlines only; body/UI/code use IBM Plex Sans / Mono.

## Fonts
All Google Fonts — no local files. Load:
```html
<link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400;0,9..144,500;1,9..144,400;1,9..144,500&family=IBM+Plex+Sans:wght@400;500&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
```

## How to use
- **Visual artifacts** (slides, mocks, throwaway prototypes): copy the assets/components you need and produce static HTML files for the user to view. Reuse the JSX components in `ui_kits/*` and the slide patterns in `slides/`.
- **Production code**: copy assets and read the rules here to design accurately in-brand.
- If invoked with no other guidance, ask the user what they want to build, ask a few focused questions, then act as an expert designer outputting HTML artifacts or production code as the need dictates.

## Defaults when unspecified
Warm neutrals as the base, one sienna action per view, generous whitespace, hairline borders over shadows, sentence case everywhere, Lucide outline icons, no emoji in UI.
